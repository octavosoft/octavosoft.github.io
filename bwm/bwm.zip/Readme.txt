
To install the program, select install.bat and press Enter.

To run the program, select bwm_demo_v1.0.10-9-ga76b2a3.exe and press Enter.

For a visual description of how to use the program please watch:

https://youtu.be/6OVLpLPAv0E

Please send any questions or comments to bwm@octavosoft.org

Happy Browsing!


Please see below the list of default shortcuts:

'!' stands for Alt key
'^' stands for Control key
'+' stands for Shift key
'#' stands for Windows key
SC033 stands for "<" key
SC034 stands for ">" key


[HotkeysActiveInBrowser]

ShowBrowserList=F1
PreviousWindow=!SC033
NextWindow=!SC034
BackTrackPrevWindow=^SC033
BackTrackNextWindow=^SC034
OpenKeySettings=F7
EditName=F2
CloseCategory=F8


[HotkeysINActiveInBrowser]

LastActiveWindow=^+z


[HotkeysAlwaysActive]

SuspendBWM=#Esc
MyReload=#+z
MyExit=^+q
SetBrowser=!+q
