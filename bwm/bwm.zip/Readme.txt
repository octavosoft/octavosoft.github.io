
To install the program, select install.bat and press Enter.

If necessary, click the 'Run' and 'Open' buttons.

To run the program, select bwm_demo_v1.0.15.exe and press Enter.

If needed, uncheck 'Always ask before opening this file' and click the 'Run' button.

For a visual description of how to use the program please watch:

https://youtu.be/foDX6Jfnazs

Please send any questions or comments to bwm@octavosoft.org

Happy Browsing!


Please see below the list of default shortcuts:

'!' stands for Alt key
'^' stands for Control key
'+' stands for Shift key
'#' stands for Windows key
SC033 stands for "<" key
SC034 stands for ">" key


[HotkeysActiveInBrowser]

ShowBrowserList=F1
PreviousWindow=!SC033
NextWindow=!SC034
BackTrackPrevWindow=^SC033
BackTrackNextWindow=^SC034
OpenKeySettings=F7
EditName=F2
CloseCategory=F8


[HotkeysINActiveInBrowser]

LastActiveWindow=^+z


[HotkeysAlwaysActive]

SuspendBWM=#Esc
MyReload=#+z
MyExit=^+q
SetBrowser=!+q
