
!!! Important!!!

Check that the executable file has not been modified by running the following command:

double click on check_executable_file.bat

The hash key displayed has to be the same as the one displayed here:

octavosoft.org/bwm.hashkey.html

For a visual description of how to use the program please watch:

Please send any questions or comments at bwm@octavosoft.org

Happy Browsing!